	$(document).ready(function()
	{

		$('#fichero').change(function()
		{
			var ficheros=this.files;
			//alert(ficheros);

			for(var i=0; i< ficheros.length; i++)
			{
				//alert(ficheros[i].name); //lee los datos de las imágenes que cojo

				var reader=new FileReader();
				reader.onload=function(e)
				{
					//$('#frmfoto+img').remove();
					//borra el anterior, para que no se acumulen visualizados
					$('#frmfoto').after('<img src="'+e.target.result+'" height="75"/>');
					//muestra la(s) imagen(es) justo después del form, previsualiza
				}
				reader.readAsDataURL(ficheros[i]);
			}
		})

	});