<?php
include "sesion.php";
// Turn off all error reporting
error_reporting(0);
?>

<?php
include "conexion.php";
$username=$_SESSION['username'];

$archivos = array_filter($_FILES['archivo']['name']); //cojo todas las imágenes que he cogido en upload.php en un array
$tag=$_POST['etiqueta'];
//$_FILES['imagen']['size'];
//$_FILES['imagen']['type'];
$total = count($_FILES['archivo']['name']); //cuento el total de imágenes 
//echo $total;



    for( $i=0 ; $i < $total ; $i++ ) { //por cada imagen, meto sus datos en variables normales, el temp name, el size y el type
        $temp = $_FILES['archivo']['tmp_name'][$i];
        $size=$_FILES['archivo']['size'][$i];
        $type=$_FILES['archivo']['type'][$i];
        $ubicacion=str_replace(' ', '-', $_FILES['archivo']['name'][$i]);//reemplaza los espacios por guiones si el nombre de la imagen tiene espacios
        $ubicacion = "./img/" . $ubicacion; //ruta donde quiero guardarlos en el server
        
        
        $allowedExts = array("jpg", "jpeg", "png"); //solo permito estas extensiones
        $extension = strtolower(end(explode(".", $ubicacion)));//aquí guardo la extensión, y si está en mayus la paso a minus, por si viene en plan .JPG en vez de .jpg
        
        if(!in_array($extension, $allowedExts)){ //comprobar que la extensión del archivo está en este array y es válida, si no está, da error
	    echo "<p class='aviso'>Has elegido algún archivo no válido <a href='upload.php'>Volver</a></p>";//alert
        }
        else{//si está, comprobamos el nombre del archivo
        
            if(file_exists($ubicacion)){ //si ya existe un archivo con el mismo nombre, le añado una cadena alfanumérica random de 5 caracteres de forma que es imposible que el nombre se repita, y así no da errores (si el nombre ya existe, no se sube, por eso hago esto xD)
                function getRandomCode(){
                $an = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                $su = strlen($an) - 1;
                return substr($an, rand(0, $su), 1) .
                        substr($an, rand(0, $su), 1) .
                        substr($an, rand(0, $su), 1) .
                        substr($an, rand(0, $su), 1) .
                        substr($an, rand(0, $su), 1);
}
                $ubicacion="./img/" .getRandomCode(). $_FILES['archivo']['name'][$i]; //le añado la cadena alfanumérica justo delante del nombre de la imagen en el servidor. Si subo por ejemplo foto.jpg al servidor y ese nombre ya existe, se subirá como FL9S1foto.jpg, por ejemplo
            }
            move_uploaded_file($temp, $ubicacion); //esta función mueve la imagen al server, necesita los parámetros tmp_name y name de arriba, que ahora son las variables normales $temp y $ubicacion
            $sql = "INSERT INTO galeria (ubicacion, type, size, tag, username) VALUES('" .$ubicacion. "','" .$type. "','" .$size. "','" .$tag. "','" .$username. "')";
            $insertar=mysqli_query($conexion, $sql); //este insert en la base de datos es necesario para mostrar luego las imágenes, ya que al hacer el select sacaremos la ruta, y esa misma ruta la ponemos dentro de una etiqueta img para que salga en la página, en plan: echo "<img src='$row["ubicacion"]'>";
        }
    }//cierre for
        
        if(!$insertar){
            echo '<script> alert("Ha ocurrido un problema");
            </script>';
        }else{
            echo '<script> alert("Imágenes subidas");
            </script>';
            echo '<META HTTP-EQUIV="Refresh" CONTENT="0;URL=upload.php">';
        }
    
    

?>