<?php
include "sesion.php";
include "conexion.php";
$username=$_SESSION['username'];
$check=mysqli_query($conexion, "SELECT sesion_id FROM usuario WHERE username = '$username'");

$resultcheck =mysqli_fetch_array($check);
$resultado=$resultcheck['sesion_id'];

if($resultado==0){
        $cerrarcheck=mysqli_query($conexion, "UPDATE usuario SET sesion_id=0 WHERE username='$username'");
        unset($_SESSION);
        session_destroy();
        
        echo "<link rel='stylesheet' type='text/css' href='css/common.css' />";
	    echo "<link rel='stylesheet' type='text/css' href='css/pc.css' />";
        echo "<p class='aviso'>Se ha cerrado la sesión iniciada. Vuelve a loguearte <a href='login.php'>Aquí</a></p>";
}else{
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/common.css" />
	<link rel="stylesheet" type="text/css" href="css/pc.css" />
	<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>

    <script src="js/previsualizar.js" type="text/javascript" ></script>
	<title>Subir imágenes</title>
</head>


<body>
    <div id="header">
        <span class="h-inicio"><?php echo $username?></span>
        <a href="logout.php"><img src="imgsv/logout.png" class="logout" title="Cerrar sesión"></a>
			<ul class="nav">
			   
				<li><a href="inicio.php" class="a-nodeco"><span>Inicio</span></a></li>
				<li><span>Perfil</span>
					<ul>
						<li><a href="profile.php" class="link">Ver perfil</a></li>
						<li><span>Configuración ▾</a>
							<ul>
								<li><a href="cambiarfoto.php" class="link">Cambiar imagen perfil</a></li>
								<li><a href="cambiarpass.php" class="link">Cambiar contraseña</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li><span class="actual">Archivos</span>
					<ul>
						<li><a href="buscar_imagenes.php" class="link">Buscar imágenes</a></li>
						<li><span>Subir archivos ▾</a>
							<ul class="ul2">
							    <li><a href="gallery.php" class="link">Mis imágenes</a></li>
							    <li><a href="archivo.php" class="link">Mis documentos</a></li>
								<li><a href="upload.php" class="link">Subir imágenes</a></li>
								<li><a href="subirficheros.php" class="link">Subir documentos</a></li>
							</ul>
						</li>
					</ul>
				</li>
			</ul>
		
	</div>
	
	<div class="cont-ini">
    <a href="inicio.php" class="a-inicio"><img src="imgsv/sm.png" class="a-imagen"></a>

    </div>
    <p>Página para subir solo imágenes</p> <!--el previsualizar.js de arriba muestra las imágenes que queremos subir, una tras otra, antes de subirlas-->
	<form method="POST" action="uploaded.php" enctype="multipart/form-data" id="frmfoto"> <!--el enctype ese es necesario para cualquier form en el que se recojan archivos-->
		<input type="file" name="archivo[]" id="fichero" accept=".jpg, .jpeg, .png" multiple required> <!--archivo[] y multiple porque podemos subir varios, esto se puede cambiar si solo se sube un archivo-->
		<input type="text" name="etiqueta" placeholder="etiqueta (opcional)"> <!--esto es un input normal xD-->
		<input type="submit" name="submit" value="Subir">
	</form>

</body>
</html>
<?php
}
?>